<?php
    include('connection.php');
    session_start();

    if(isset($_POST["update"]))
    {
        $id = $_POST["id"];
        $fnm = $_POST["fname"];
        $lnm = $_POST["lname"];
        $em = $_POST["email"];
        $cont = $_POST["contact"];
        $pass = $_POST["pass"];
    
        $sql = "UPDATE user SET u_fname='$fnm' , u_lname='$lnm' , u_email='$em' , u_contact_no='$cont' , u_password='$pass' WHERE u_id ='$id'";
        $check = mysqli_query($conn ,$sql);   
        if($check)
            {
                $_SESSION['message'] = " User Details Updated Successfully";
                header("Location: update_profile.php");
            }
        else
            {
                echo mysqli_error($conn);
            }    
    }
?>