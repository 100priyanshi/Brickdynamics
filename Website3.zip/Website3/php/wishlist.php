<?php
include('connection.php');
session_start();

if(isset($_SESSION['u_email']))
{
    $em = $_SESSION['u_email'];
    $sql = "SELECT * FROM user WHERE u_email='$em'";
    $result = mysqli_query($conn,$sql);
    while ($row = mysqli_fetch_assoc($result))
    {
        $user_id = $row['u_id'];
        if(isset($_POST['wishlist']))
        {
            $p_id = $_POST['wishlist'];
            if(checkWishlist($conn,$user_id,$p_id))
            {
                removeWishlist($conn,$user_id,$p_id);
                $_SESSION['message'] = "Property Removed From Wishlist";
                header('Location: search.php');
            }
            else
            {
                addWishlist($conn,$user_id,$p_id);
                $_SESSION['message'] = "Property Added To Wishlist";
                header('Location: search.php');
            }
        }
    }
}
function checkWishList($connection, $user, $property)
{
    $conn = $connection;
    $user_id = $user;
    $p_id = $property;

    $sql = "SELECT * FROM wishlist WHERE u_id = '$user_id' AND p_id = '$p_id'";
    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0)
    {
        return true;
    }
    return false;
}
function addWishlist($connection, $user, $property)
{
    $conn = $connection;
    $user_id = $user;
    $p_id = $property;

    $sql2 = "INSERT INTO wishlist (u_id,p_id) VALUES ('$user_id','$p_id')";
    $check1 = mysqli_query($conn ,$sql2);
}
function removeWishlist($connection, $user, $property)
{
    $conn = $connection;
    $user_id = $user;
    $p_id = $property;

    $sql1 = "DELETE FROM wishlist WHERE u_id = '$user_id' AND p_id = '$p_id'";
    $check = mysqli_query($conn ,$sql1);
}